### vRAM Requirements

To check vRAM requirement for a model, add models to check in `gh-config.json`.

Then run `npm install` followed by `npm start`.