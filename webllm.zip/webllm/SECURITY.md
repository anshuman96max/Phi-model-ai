# Security Policy

## Reporting a Vulnerability

For security concerns or vulnerability reports, please send email to mlc-llm-private@googlegroups.com.
