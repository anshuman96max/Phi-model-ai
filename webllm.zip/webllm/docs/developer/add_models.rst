Adding Models
=============

WebLLM allows you to compile custom language models using `MLC LLM <https://llm.mlc.ai/>`_ and then serve compiled model through WebLLM.

For instructions of how to compile and add custom models to WebLLM, check the `MLC LLM documentation here <https://llm.mlc.ai/docs/deploy/webllm.html>`_. 